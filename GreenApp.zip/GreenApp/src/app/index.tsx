import React from 'react';

import { SheetProvider } from 'react-native-actions-sheet'; // Importação do provider do modal
import './../components/sheet/sheets';
import { createStackNavigator } from '@react-navigation/stack';
// Importação das telas
import Mapa from './telas/Mapa';
import Inicio from './telas/Inicio';
import Lista from './telas/Lista';
import Descricao from './telas/Descricao';

const Stack = createStackNavigator(); // Criação de uma pilha de navegação

export default function index() {
  return (
    <SheetProvider>
      <Stack.Navigator
        initialRouteName="Inicio" // Tela inicial
        screenOptions={{
          headerShown: false, // Oculta o cabeçalho
        }}
      >
        <Stack.Screen name="Mapa" component={Mapa} />
        <Stack.Screen name="Inicio" component={Inicio} />
        <Stack.Screen name="Lista" component={Lista} />
        <Stack.Screen name="Descricao" component={Descricao} />
      </Stack.Navigator>
    </SheetProvider>
  );
}
