import React, { FC } from 'react';
import { StyleSheet, Text, View, ScrollView } from 'react-native';
import { Dado } from '@/src/Service/Endpoints'; // Importa o tipo de dado retornado pela API
import { Colors } from '@/src/constants/Colors'; // Importa as cores do seu tema
import TopBar from '@/src/components/layout/TopBar'; // Componente de barra superior

type Props = {
  route: {
    params: {
      dados: Dado[];
    };
  };
};

const Lista: FC<Props> = ({ route }) => {
  return (
    <View style={styles.content}>
      <TopBar title="Imóveis Autuados" />
      <ScrollView contentContainerStyle={styles.container}>
        {route.params.dados.map((dado: Dado) => (
          <View key={dado.id} style={styles.card}>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Nome Fantasia:</Text>
              <Text style={styles.text}>{dado.nomeFantasia}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Razão Social:</Text>
              <Text style={styles.text}>{dado.razaoSocial}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Endereço:</Text>
              <Text style={styles.text}>{dado.endereco}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Data:</Text>
              <Text style={styles.text}>{dado.data}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Número do Auto:</Text>
              <Text style={styles.text}>{dado.numeroAuto}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>Infrações:</Text>
              <Text style={styles.text}>{dado.infracoes}</Text>
            </View>
            <View style={styles.cardContent}>
              <Text style={styles.label}>CNPJ/Sequencial do imóvel:</Text>
              <Text style={styles.text}>{dado.cnpj}</Text>
            </View>
          </View>
        ))}
      </ScrollView>
    </View>
  );
};

export default Lista;

const styles = StyleSheet.create({
  content: {
    flex: 1,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
    padding: 10,
    color: Colors.light.primary,
  },
  container: {
    flexDirection: 'column',
    padding: 10,
    gap: 10,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: Colors.light.card,
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 2,
    flexWrap: 'wrap',
    borderBottomWidth: 2,
    borderBottomColor: Colors.light.primary,
  },
  cardContent: {
    flexBasis: '50%',
  },
  label: {
    fontWeight: 'bold',
  },
  text: {
    fontSize: 14,
  },
});
