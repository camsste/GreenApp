import { StyleSheet, Text, View } from 'react-native';
import React from 'react';
import TopBar from '@/src/components/layout/TopBar';

const Descricao = () => {
  return (
    <View style={styles.container}>
      <TopBar title="Descrição" />
      <View style={styles.content}>
        <Text style={styles.title}>API Utilizada</Text>
        <Text style={styles.text}>
          A API utilizada neste projeto é fornecida pelo portal de dados abertos
          da Prefeitura do Recife. A URL da API é:
        </Text>
        <Text style={styles.url}>
          http://dados.recife.pe.gov.br/api/3/action/datastore_search?resource_id=41dda42a-2a09-47ed-8667-123b024e1546
        </Text>
        <Text style={styles.text}>
          Esta API fornece dados de infrações registradas na cidade do Recife.
          Abaixo estão os principais campos que são retornados pela API:
        </Text>
        <Text style={styles.listItem}>
          - **cnpj**: O CNPJ da entidade registrada.
        </Text>
        <Text style={styles.listItem}>
          - **data**: A data em que a vistoria foi realizada.
        </Text>
        <Text style={styles.listItem}>
          - **endereco**: O endereço onde a infração foi registrada.
        </Text>
        <Text style={styles.listItem}>
          - **id**: Um identificador único para o registro.
        </Text>
        <Text style={styles.listItem}>
          - **infracoes**: As infrações cometidas, conforme o artigo da
          legislação.
        </Text>
        <Text style={styles.listItem}>
          - **latitude**: A latitude da localização da infração.
        </Text>
        <Text style={styles.listItem}>
          - **longitude**: A longitude da localização da infração.
        </Text>
        <Text style={styles.listItem}>
          - **nomeFantasia**: O nome fantasia da entidade registrada.
        </Text>
        <Text style={styles.listItem}>
          - **numeroAuto**: O número do auto de infração.
        </Text>
        <Text style={styles.listItem}>
          - **razaoSocial**: A razão social da entidade registrada.
        </Text>
      </View>
    </View>
  );
};

export default Descricao;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    marginTop: 20,
    padding: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  text: {
    fontSize: 16,
    marginBottom: 10,
  },
  url: {
    fontSize: 16,
    color: 'blue',
    marginBottom: 20,
  },
  listItem: {
    fontSize: 16,
    marginBottom: 5,
  },
});
