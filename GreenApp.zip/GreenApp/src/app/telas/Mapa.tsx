import React, { useEffect, useState } from 'react';
import {
  Image,
  StyleSheet,
  View,
  ActivityIndicator,
  Alert,
} from 'react-native';
import MapView, { Marker, Callout } from 'react-native-maps';
import * as Location from 'expo-location';
import { Colors } from '@/src/constants/Colors'; // Importa as cores do seu tema
import Endpoints, { Dado } from '@/src/Service/Endpoints'; // Importa os endpoints da sua API
import { SheetManager } from 'react-native-actions-sheet';
import DetalhesMarcador from '@/src/components/layout/DetalhesMarcador'; // Componente para detalhar marcador
import MapHeader from '@/src/components/layout/MapHeader'; // Componente para cabeçalho do mapa
import MapFooter from '@/src/components/layout/MapFooter'; // Componente para rodapé do mapa

export default function Mapa() {
  const [localizacao, setLocalizacao] = useState<any>(null); // Estado para armazenar a localização do usuário
  const [dados, setDados] = useState<Dado[]>([]); // Estado para armazenar os dados dos locais
  const [mapaSatelite, setMapaSatelite] = useState<boolean>(false); // Estado para controlar a exibição do mapa satélite

  // Solicitar permissão para acessar a localização do usuário
  useEffect(() => {
    (async () => {
      // Solicita permissão de localização
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        // Define mensagem de erro se a permissão for negada
        Alert.alert(
          'Erro',
          'A permissão para acessar a localização foi negada.',
        );
        return;
      }

      // Obtém a localização atual do usuário
      let loc = await Location.getCurrentPositionAsync({});
      // Define a localização no estado (usa coordenadas de desenvolvimento se em modo DEV)
      setLocalizacao(loc);
    })();
  }, []);

  // Função para buscar dados dos locais a partir da API
  const BuscarDados = async () => {
    const dados = await Endpoints.getData();
    setDados(dados);
  };

  // Chama a função BuscarDados quando o componente é montado
  useEffect(() => {
    BuscarDados();
  }, []);

  // Oculta o modal de detalhes ao arrastar o mapa
  const onDragMap = () => {
    SheetManager.hide('detalhes-sheet');
  };

  // Abre o modal de detalhes do marcador ao pressionar o callout
  const abrirModal = async (dado: Dado) => {
    await SheetManager.show('detalhes-sheet', {
      payload: {
        value: dado,
      },
    });
  };

  // Mostra um indicador de carregamento enquanto a localização não é obtida
  if (localizacao === null) {
    return (
      <ActivityIndicator
        size="large"
        color={Colors.light.primary} // Cor definida no seu tema
        style={styles.indicadorDeCarregamento}
      />
    );
  }

  return (
    <View style={styles.container}>
      {/* Mapa exibindo a localização do usuário */}
      <MapView
        style={styles.map}
        onTouchStart={onDragMap}
        mapType={mapaSatelite ? 'hybrid' : 'standard'}
        initialRegion={{
          longitude: localizacao.coords.longitude,
          latitude: localizacao.coords.latitude,
          latitudeDelta: 0.1, // Zoom inicial
          longitudeDelta: 0.1, // Zoom inicial
        }}
        // showsUserLocation={true}
      >
        <Marker
          coordinate={{
            latitude: localizacao.coords.latitude,
            longitude: localizacao.coords.longitude,
          }}
          title="Você está aqui"
          description={`latitude: ${localizacao.coords.latitude}, longitude: ${localizacao.coords.longitude}`}
        />

        {/* Exibe marcadores para cada dado retornado pela API */}
        {dados.map(dado => (
          <Marker
            key={dado.id}
            coordinate={{
              latitude: Number(dado.latitude),
              longitude: Number(dado.longitude),
            }}
          >
            <Image
              source={require('./../../../assets/images/danger.png')}
              resizeMode="contain"
              style={{ width: 40, height: 40 }}
            />
            <Callout
              onPress={() => {
                abrirModal(dado);
              }}
              style={styles.callout}
            >
              <DetalhesMarcador dado={dado} />
            </Callout>
          </Marker>
        ))}
      </MapView>
      <MapHeader
        mapaSatelite={mapaSatelite}
        setMapaSatelite={setMapaSatelite}
      />
      <MapFooter dados={dados} />
    </View>
  );
}

// Estilos do componente
const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  map: {
    width: '100%',
    height: '100%',
  },
  indicadorDeCarregamento: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  callout: {
    width: 200,
    backgroundColor: 'white',
    borderRadius: 10,
  },
});
