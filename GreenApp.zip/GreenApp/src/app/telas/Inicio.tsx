import { StyleSheet, Text, TouchableOpacity, View, Image } from 'react-native';
import React from 'react';
import { Colors } from '@/src/constants/Colors';
import { useNavigation } from '@react-navigation/native';

const Inicio = () => {
  // Hook para navegação
  const navigation = useNavigation();

  // Função acionada quando clica no botão iniciar
  const handleStart = () => {
    navigation.navigate('Mapa');
  };

  const handleDescricao = () => {
    navigation.navigate('Descricao');
  };

  return (
    <View style={styles.container}>
      {/* Cabeçalho com a imagem */}
      <View style={styles.header}>
        <Image
          source={require('../../../assets/images/imageMap.png')}
          style={styles.imagem}
        />
      </View>

      {/* Corpo do texto */}
      <View style={styles.body}>
        <Text style={styles.titulo}>Bem-vindo</Text>
        <Text style={styles.descricao}>
          Este aplicativo ajuda a identificar locais que sofreram infrações
          ambientais. Navegue pelo mapa e fique informado sobre as infrações na
          sua região.
        </Text>
      </View>

      {/* Botão de iniciar */}
      <TouchableOpacity onPress={handleStart} style={styles.botaoIniciar}>
        <Text style={styles.textoBotao}>Iniciar</Text>
      </TouchableOpacity>
      {/* Botão de descrição */}
      <TouchableOpacity onPress={handleDescricao} style={styles.botaoDescricao}>
        <Text style={styles.textoBotao}>Descrição do App</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Inicio;

const styles = StyleSheet.create({
  // Estilo do container principal
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: Colors.light.background,
    padding: 20,
  },
  // Estilo do cabeçalho
  header: {
    flex: 2,
    width: '100%',
    marginBottom: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  // Estilo do corpo
  body: {
    flex: 2,
    width: '100%',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  // Estilo do botão iniciar
  botaoIniciar: {
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    backgroundColor: Colors.light.primary,
    borderRadius: 8,
    margin: 10,
  },
  // Estilo do texto do botão
  textoBotao: {
    color: Colors.light.background,
    fontSize: 18,
    fontWeight: 'bold',
  },
  botaoDescricao: {
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    backgroundColor: Colors.light.secondary,
    borderRadius: 8,
  },
  // Estilo da imagem
  imagem: {
    height: 350,
    width: '90%',
  },
  // Estilo do título
  titulo: {
    fontSize: 35,
    fontWeight: 'bold',
    color: Colors.light.primary,
    marginBottom: 10,
  },
  // Estilo da descrição
  descricao: {
    fontSize: 20,
    color: Colors.light.secondary,
    textAlign: 'center',
    width: '100%',
    marginBottom: 10,
    paddingHorizontal: 20,
  },
});
