import axios from 'axios';

// Tipo para armazenar os dados retornados pela API
export type Dado = {
  id: string;
  nomeFantasia: string;
  endereco: string;
  latitude: string | number;
  longitude: string | number;
  data: string;
  infracoes: string;
  numeroAuto: string;
  cnpj: string;
  razaoSocial: string;
};

const getData = async (): Promise<Dado[]> => {
  try {
    const response = await axios.get('http://dados.recife.pe.gov.br/api/3/action/datastore_search?resource_id=41dda42a-2a09-47ed-8667-123b024e1546');
    const dados: Dado[] = response.data.result.records.map((dado: any) => ({
      id: dado._id,
      nomeFantasia: dado['NOME FANTASIA'],
      endereco: dado['ENDEREÇO'],
      latitude: dado.latitude,
      longitude: dado.longitude,
      data: dado['DATA DA VISTORIA'],
      infracoes: dado['INFRAÇÕES'],
      numeroAuto: dado['Nº AUTO'],
      cnpj: dado['CNPJ, CPF OU SEQUENCIAL DO IMÓVEL'],
      razaoSocial: dado['RAZÃO SOCIAL'],
    }));

    return dadosComLatLog(dados);
  } catch (error) {
    console.log(error);
    return [];
  }
};

const dadosComLatLog = (dados: Dado[]): Dado[] => {
  return dados.filter(dado => dado.latitude && dado.longitude);
};

export default { getData };
