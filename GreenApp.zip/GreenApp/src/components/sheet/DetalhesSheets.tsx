import { StyleSheet, Text, View } from 'react-native';
import ActionSheet from 'react-native-actions-sheet';
import React, { FC } from 'react';
import { Colors } from '@/src/constants/Colors';
import { Dado } from '@/src/Service/Endpoints';

type Props = {
  payload: {
    value: Dado;
  };
};

const DetalhesSheets: FC<Props> = ({ payload }) => {
  const { value } = payload;
  return (
    <ActionSheet containerStyle={styles.container}>
      <View style={styles.body}>
        <Text style={styles.title}>{value.nomeFantasia}</Text>
        <Text style={styles.label}>Razão Social:</Text>
        <Text style={styles.text}>{value.razaoSocial}</Text>
        <Text style={styles.label}>Endereço:</Text>
        <Text style={styles.text}>{value.endereco}</Text>
        <Text style={styles.label}>Data da Vistoria:</Text>
        <Text style={styles.text}>{value.data}</Text>
        <Text style={styles.label}>Número do Auto:</Text>
        <Text style={styles.text}>{value.numeroAuto}</Text>
        <Text style={styles.label}>Infrações:</Text>
        <Text style={styles.text}>{value.infracoes}</Text>
        <Text style={styles.label}>CNPJ:</Text>
        <Text style={styles.text}>{value.cnpj}</Text>
        <Text style={styles.label}>Latitude:</Text>
        <Text style={styles.text}>{value.latitude}</Text>
        <Text style={styles.label}>Longitude:</Text>
        <Text style={styles.text}>{value.longitude}</Text>
      </View>
    </ActionSheet>
  );
};

export default DetalhesSheets;

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: Colors.light.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  body: {
    width: '100%',
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  label: {
    fontSize: 14,
    fontWeight: 'bold',
    marginTop: 10,
  },
  text: {
    fontSize: 14,
    marginBottom: 5,
  },
});
