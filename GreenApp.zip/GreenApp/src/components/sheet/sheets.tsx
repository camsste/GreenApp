import { registerSheet, SheetDefinition } from 'react-native-actions-sheet';
import DetalhesSheets, { Infracao } from './DetalhesSheets';
import { Dado } from '@/src/Service/Endpoints';

registerSheet('detalhes-sheet', DetalhesSheets);

declare module 'react-native-actions-sheet' {
  interface Sheets {
    'detalhes-sheet': SheetDefinition<{
      payload: {
        value: Dado;
      };
    }>;
  }
}

export {};
