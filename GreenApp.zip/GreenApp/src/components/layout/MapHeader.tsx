import { StyleSheet, Text, View, TouchableOpacity } from 'react-native';
import React, { FC } from 'react';
import { Colors } from '@/src/constants/Colors';
import { useNavigation } from '@react-navigation/native';

type Props = {
  mapaSatelite: boolean;
  setMapaSatelite: (value: boolean) => void;
};

const MapHeader: FC<Props> = ({ mapaSatelite, setMapaSatelite }) => {
  const navigation = useNavigation(); // Hook para navegação

  const handleBack = () => {
    navigation.goBack(); // Volta para a tela anterior
  };

  return (
    <View style={styles.header}>
      <View style={styles.container}>
        <Text style={styles.title}>Mapa das Infrações</Text>

        <Text
          onPress={() => setMapaSatelite(!mapaSatelite)}
          style={styles.buttonText}
        >
          {mapaSatelite ? 'Modo Padrão' : 'Modo Satélite'}
        </Text>
        <Text onPress={handleBack} style={styles.voltar}>
          Voltar
        </Text>
      </View>
    </View>
  );
};

export default MapHeader;

const styles = StyleSheet.create({
  header: {
    position: 'absolute',
    width: '100%',
    top: 0,
    zIndex: 10,
    height: 50,
  },
  container: {
    paddingVertical: 10,
    width: '100%',
    backgroundColor: Colors.light.primary,
    alignItems: 'center',
    justifyContent: 'space-between',
    flexDirection: 'row',
    paddingHorizontal: 20,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.light.background,
    flex: 1,
    alignSelf: 'center',
    textAlign: 'center',
  },

  buttonText: {
    position: 'absolute',
    right: 10,
    color: Colors.light.primary,
    fontWeight: 'bold',
    backgroundColor: Colors.light.background,
    paddingVertical: 3,
    paddingHorizontal: 5,
    borderRadius: 5,
  },
  voltar: {
    position: 'absolute',
    left: 10,
    color: Colors.light.background,
    fontWeight: 'bold',
    backgroundColor: Colors.light.secondary,
    paddingVertical: 3,
    paddingHorizontal: 5,
    borderRadius: 5,
  },
});
