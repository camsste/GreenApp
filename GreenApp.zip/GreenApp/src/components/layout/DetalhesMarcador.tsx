import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { FC, useCallback } from 'react';
import { Colors } from '../../constants/Colors';
import { Dado } from '../../Service/Endpoints';

type Props = {
  dado: Dado;
};

const DetalhesMarcador: FC<Props> = ({ dado }) => {
  return (
    <View>
      <Text style={styles.titulo}>{dado.nomeFantasia}</Text>
      <Text style={styles.subtitulo}>{dado.endereco}</Text>
      <Text style={styles.verMais}>ver mais</Text>
    </View>
  );
};

export default DetalhesMarcador;

const styles = StyleSheet.create({
  container: {
    height: 100,
    backgroundColor: Colors.light.background,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titulo: {
    fontWeight: 'bold',
    alignSelf: 'center',
  },
  subtitulo: {
    color: 'gray',
    alignSelf: 'center',
  },
  verMais: {
    color: Colors.light.primary,
    alignSelf: 'center',
    marginTop: 2,
  },
});
