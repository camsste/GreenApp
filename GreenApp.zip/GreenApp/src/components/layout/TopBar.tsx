import { StyleSheet, Text, View } from 'react-native';
import React, { FC } from 'react';
import { Colors } from '@/src/constants/Colors';
import { useNavigation } from '@react-navigation/native';

type Props = {
  title: string;
};

const TopBar: FC<Props> = ({ title }) => {
  const navigation = useNavigation(); // Hook para navegação

  // Função acionada quando clica no botão voltar
  const handleBack = () => {
    navigation.goBack(); // Volta para a tela anterior
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>{title}</Text>
      <Text onPress={handleBack} style={styles.voltar}>
        Voltar
      </Text>
    </View>
  );
};

export default TopBar;

const styles = StyleSheet.create({
  container: {
    height: 50,
    width: '100%',
    backgroundColor: Colors.light.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  titulo: {
    fontWeight: 'bold',
    alignSelf: 'center',
    fontSize: 20,
    color: Colors.light.background,
  },
  voltar: {
    position: 'absolute',
    left: 10,
    color: Colors.light.background,
    fontWeight: 'bold',
    backgroundColor: Colors.light.secondary,
    paddingVertical: 3,
    paddingHorizontal: 5,
    borderRadius: 5,
  },
});
