import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { FC } from 'react';
import { useNavigation } from '@react-navigation/native';
import { Dado } from '../../Service/Endpoints';
import { Colors } from '@/src/constants/Colors';

type Props = {
  dados: Dado[];
};

const MapFooter: FC<Props> = ({ dados }) => {
  const navigation = useNavigation();

  const onPress = () => {
    navigation.navigate('Lista', { dados });
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.botao} onPress={onPress}>
        <Text style={styles.textoBotao}>Exibir lista de infrações</Text>
      </TouchableOpacity>
    </View>
  );
};

export default MapFooter;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    width: '100%',
    bottom: 0,
    zIndex: 10,
    backgroundColor: Colors.light.background,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -5 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  botao: {
    width: '100%',
    height: 50,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.light.primary,
    padding: 10,
    borderRadius: 5,
  },
  textoBotao: {
    color: Colors.light.background,
    fontWeight: 'bold',
    fontSize: 18,
  },
});
