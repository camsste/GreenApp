module.exports = {
  root: true,
  extends: '@react-native',
  plugins: ['simple-import-sort', 'unused-imports'],
  env: {
    es6: true,
  },
  rules: {
    'prettier/prettier': [
      'error',
      {
        endOfLine: 'auto',
        singleQuote: true,
        bracketSpacing: true,
      },
    ],

    // Typescript
    '@typescript-eslint/no-unused-vars': 'warn',
    'react-hooks/exhaustive-deps': 'off',

    // Simple import sort
    'simple-import-sort/exports': 'error',
    'simple-import-sort/imports': [
      'error',
      {
        groups: [
          // Grupo 1: Pacotes do núcleo do React e React Native
          ['^react$', '^react-native$'],
          // Grupo 2: Bibliotecas de terceiros excluindo as do React e do React Native
          // A regex negativa é usada para excluir o react e o react-native dos terceiros
          ['^react', '^react-native', '^[^.]', '^@(?!src/).*/'],
          // Grupo 3: Aliases internos que começam com @src
          ['^@src/'],
          // Grupo 5: Side-effect imports
          ['^\\u0000'],
          // Grupo 6: Importações relativas
          // Importações de diretórios pai
          ['^\\..*/'],
          // Outras importações relativas que começam com ./
          ['^\\.'],
        ],
      },
    ],
  },
};
