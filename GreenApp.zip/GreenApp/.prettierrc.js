module.exports = {
    bracketSpacing: true,
    singleQuote: true,
    trailingComma: 'all',
    arrowParens: 'avoid',
    error: {
        endOfLine: 'auto',
      }
};